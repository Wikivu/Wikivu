==================================================
Table of Contents
==================================================

1. Overview
2. Installation
3. !!! Precautions !!!
4. Running the Converter
5. Questions?


==================================================
1. Overview
==================================================

This is an experimental converter, which converts CashTrails+ 2.4 CSV files (extension .csv) into CashTrails backup files (extension .cashtrails), which can then be imported into the app.

NOTE: Unlike CashTrails backup files, CashTrails CSV files do not contain all the information stored in the app. Specifically, they do *not* contain the following:

- Photos attached to entries.
- Recurring entry templates (they do contain the generated entries themselves).
- Report presets.
- Account settings (notes, configuration), account groups.
- App settings.
- Tag categories.
- and probably some more.

When the converter runs, it creates all accounts, tags, etc as they are named in the CSV file, and sets up the accounts as best as it can, from the available information.

Only two report presets are created by default - "This Month" and "All Entries". You can add other report presets manually as needed.


==================================================
2. Installation
==================================================

You would need Python 3.4.x to run the converter. The Python installer is available at https://www.python.org/downloads/release/python-344/

Please copy the folder containing the converter to a convenient location, e.g. your Desktop, so that the file structure is as follows:
	Desktop > CashTrails2CSVToBackup > converter.py (and all the other file)

Please also copy the CSV files you'd like to convert into the same folder as the converter (so that they're in the same folder as the converter.py file).


==================================================
3. !!! Precautions !!!
==================================================

In order to ensure your data are safe, please make a backup of your data from within the app, as follows:

1. Launch CashTrails.
2. Go to More > Backups.
3. Tap the Export Backup button to create a backup file.
4. Either swipe the newly created file to the left, select the Email option, and send the backup file to yourself, or connect your device to iTunes, and copy the newly created backup file (name Backup-YYYYMMDD.cashtrails) onto your computer via the Apps > File Sharing > CashTrails[+] section for your device in iTunes.

Optionally, you can also create a CSV file for all your entries, via More > Export CSV.


==================================================
4. Running the Converter
==================================================

To run the converter, please launch Terminal (on OS X) or cmd.exe (on Windows), and change the current directory to the one containing the converter, e.g:

on OS X:

	cd ~/Desktop/CashTrails2CSVToBackup

on Windows:

	cd Desktop/CashTrails2CSVToBackup

Afterwards, you can run the converter as follows:

OS X:

	python3.4 converter.py Input.csv

Windows:

	C:\Python34\Python.exe converter.py Input.csv

or, if you'd like to combine several files into a single backup file, as follows:

OS X:

	python3.4 converter.py Input1.csv Input2.csv Input3.csv

Windows:

	C:\Python34\Python.exe converter.py Input1.csv Input2.csv Input3.csv


running the converter will create a backup file named Output.cashtrails.

After this, you can import the Output.cashtrails backup file into the app, either by emailing it to yourself, opening the message in Mail on your iPhone or iPad, tapping the attachment, and selecting the option to open it with CashTrails, or copying the backup file via iTunes, and importing it via More > Backups (by tapping the copied backup file).


==================================================
5. Questions?
==================================================

Though the converter is not officially supported, we'll do our best to help you if you run into any issues with it - just email support@cashtrails.com
