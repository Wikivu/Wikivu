#!/usr/bin/env python3
#
# This converter supports CSV files created with CashTrails+ 2.4.
#
# Copyright (c) 2014-2020 Vasyl Smyrnov. All rights reserved.

import csv
import os
import shutil
import sqlite3
import sys
import time
import uuid
import zipfile
from enum import Enum, IntEnum

class CSVFileType(Enum):
    UTF8CSV = 1
    UTF16TSV = 2
    UTF8ScSV = 3

class CSVLanguage(Enum):
    English = 1
    German = 2
    Spanish = 3
    French = 4
    Italian = 5
    Dutch = 6
    Portuguese = 7
    Russian = 8
    Ukrainian = 9
    ChineseSimplified = 10

TIME_AM_SUFFIX = " AM"
TIME_PM_SUFFIX = " PM"

class EntryType(IntEnum):
    Expense = 0
    Income = 1
    Transfer = 2
    BalanceAdjustment = 3

class InputEntry:
    def __init__(self, \
        inputFilePath, \
        rowNumber, \
        dateString, \
        timeString, \
        entryType, \
        amount1StringOrEmpty, \
        currency1CodeOrEmpty, \
        amount2StringOrEmpty, \
        currency2CodeOrEmpty, \
        amount3StringOrEmpty, \
        currency3CodeOrEmpty, \
        amount4StringOrEmpty, \
        currency4CodeOrEmpty, \
        tagNameList, \
        note, \
        partyNameOrEmpty, \
        account1NameOrEmpty, \
        account2NameOrEmpty, \
        groupNameOrEmpty):
        self.inputFilePath = inputFilePath
        self.rowNumber = rowNumber
        self.dateString = dateString
        self.timeString = timeString
        self.entryType = entryType
        self.amount1StringOrEmpty = amount1StringOrEmpty
        self.currency1CodeOrEmpty = currency1CodeOrEmpty
        self.amount2StringOrEmpty = amount2StringOrEmpty
        self.currency2CodeOrEmpty = currency2CodeOrEmpty
        self.amount3StringOrEmpty = amount3StringOrEmpty
        self.currency3CodeOrEmpty = currency3CodeOrEmpty
        self.amount4StringOrEmpty = amount4StringOrEmpty
        self.currency4CodeOrEmpty = currency4CodeOrEmpty
        self.tagNameList = tagNameList
        self.note = note
        self.partyNameOrEmpty = partyNameOrEmpty
        self.account1NameOrEmpty = account1NameOrEmpty
        self.account2NameOrEmpty = account2NameOrEmpty
        self.groupNameOrEmpty = groupNameOrEmpty

TEMPORARY_OUTPUT_DIRECTORY_NAME = "__Output"
EMPTY_MAIN_DATABASE_FILE_NAME = "KoreEmptyMain.db"
BACKUP_DIRECTORY_NAME = "Backup"
MAIN_DATABASE_FILE_NAME = "Main.db"
FILES_DIRECTORY_NAME = "Files"
OUTPUT_BACKUP_FILE_NAME = "Output.cashtrails"

def makeUUID():
    return str(uuid.uuid4()).lower().replace("-", "")

class Currencies:
    def addCurrency(self, currencyID, currencyCode):
        assert (currencyID not in self.currencyIDToCodeDict)
        assert (currencyCode not in self.currencyCodeToIDDict)
        self.currencyIDToCodeDict[currencyID] = currencyCode
        self.currencyCodeToIDDict[currencyCode] = currencyID

    def __init__(self):
        self.currencyIDToCodeDict = {}
        self.currencyCodeToIDDict = {}
        self.addCurrency(1, 'HRK')
        self.addCurrency(2, 'HUF')
        self.addCurrency(3, 'CDF')
        self.addCurrency(4, 'ILS')
        self.addCurrency(5, 'NGN')
        self.addCurrency(6, 'GYD')
        self.addCurrency(7, 'BYR')
        self.addCurrency(8, 'BHD')
        self.addCurrency(9, 'SZL')
        self.addCurrency(10, 'INR')
        self.addCurrency(11, 'SDG')
        self.addCurrency(12, 'PEN')
        self.addCurrency(13, 'EUR')
        self.addCurrency(14, 'QAR')
        self.addCurrency(15, 'PGK')
        self.addCurrency(16, 'LRD')
        self.addCurrency(17, 'ISK')
        self.addCurrency(18, 'SYP')
        self.addCurrency(19, 'TRY')
        self.addCurrency(20, 'UAH')
        self.addCurrency(21, 'SGD')
        self.addCurrency(22, 'MMK')
        self.addCurrency(23, 'NIO')
        self.addCurrency(24, 'BIF')
        self.addCurrency(25, 'AFN')
        self.addCurrency(26, 'LKR')
        self.addCurrency(27, 'GTQ')
        self.addCurrency(28, 'CHF')
        self.addCurrency(29, 'THB')
        self.addCurrency(30, 'AMD')
        self.addCurrency(31, 'AOA')
        self.addCurrency(32, 'SEK')
        self.addCurrency(33, 'SAR')
        self.addCurrency(34, 'KWD')
        self.addCurrency(35, 'IRR')
        self.addCurrency(36, 'WST')
        self.addCurrency(37, 'BMD')
        self.addCurrency(38, 'GWP')
        self.addCurrency(39, 'BGN')
        self.addCurrency(40, 'PHP')
        self.addCurrency(41, 'XAF')
        self.addCurrency(42, 'BDT')
        self.addCurrency(43, 'NOK')
        self.addCurrency(44, 'BOB')
        self.addCurrency(45, 'TZS')
        self.addCurrency(46, 'VEF')
        self.addCurrency(47, 'VUV')
        self.addCurrency(48, 'ANG')
        self.addCurrency(49, 'BND')
        self.addCurrency(50, 'XCD')
        self.addCurrency(51, 'SCR')
        self.addCurrency(52, 'KYD')
        self.addCurrency(53, 'DJF')
        self.addCurrency(54, 'LSL')
        self.addCurrency(55, 'MOP')
        self.addCurrency(56, 'ALL')
        self.addCurrency(57, 'UZS')
        self.addCurrency(58, 'UYU')
        self.addCurrency(59, 'PLN')
        self.addCurrency(60, 'LTL')
        self.addCurrency(61, 'LYD')
        self.addCurrency(62, 'JPY')
        self.addCurrency(63, 'MNT')
        self.addCurrency(64, 'FJD')
        self.addCurrency(65, 'ZWL')
        self.addCurrency(66, 'KPW')
        self.addCurrency(67, 'PKR')
        self.addCurrency(68, 'MRO')
        self.addCurrency(69, 'OMR')
        self.addCurrency(70, 'GBP')
        self.addCurrency(71, 'LVL')
        self.addCurrency(72, 'SKK')
        self.addCurrency(73, 'SHP')
        self.addCurrency(74, 'GEL')
        self.addCurrency(75, 'TND')
        self.addCurrency(76, 'DKK')
        self.addCurrency(77, 'NPR')
        self.addCurrency(78, 'KRW')
        self.addCurrency(79, 'BSD')
        self.addCurrency(80, 'CRC')
        self.addCurrency(81, 'EGP')
        self.addCurrency(82, 'MAD')
        self.addCurrency(83, 'MZE')
        self.addCurrency(84, 'AUD')
        self.addCurrency(85, 'SLL')
        self.addCurrency(86, 'MWK')
        self.addCurrency(87, 'RSD')
        self.addCurrency(88, 'NZD')
        self.addCurrency(89, 'SRD')
        self.addCurrency(90, 'CLP')
        self.addCurrency(91, 'RUB')
        self.addCurrency(92, 'NAD')
        self.addCurrency(93, 'HKD')
        self.addCurrency(94, 'GMD')
        self.addCurrency(95, 'VND')
        self.addCurrency(96, 'LAK')
        self.addCurrency(97, 'CUC')
        self.addCurrency(98, 'RON')
        self.addCurrency(99, 'MUR')
        self.addCurrency(100, 'MXN')
        self.addCurrency(101, 'BRL')
        self.addCurrency(102, 'STD')
        self.addCurrency(103, 'AWG')
        self.addCurrency(104, 'MVR')
        self.addCurrency(105, 'PAB')
        self.addCurrency(106, 'TJS')
        self.addCurrency(107, 'GNF')
        self.addCurrency(108, 'MGA')
        self.addCurrency(109, 'ETB')
        self.addCurrency(110, 'ZAR')
        self.addCurrency(111, 'COP')
        self.addCurrency(112, 'IDR')
        self.addCurrency(113, 'SVC')
        self.addCurrency(114, 'CVE')
        self.addCurrency(115, 'TTD')
        self.addCurrency(116, 'GIP')
        self.addCurrency(117, 'PYG')
        self.addCurrency(118, 'MZN')
        self.addCurrency(119, 'FKP')
        self.addCurrency(120, 'KZT')
        self.addCurrency(121, 'USD')
        self.addCurrency(122, 'UGX')
        self.addCurrency(123, 'RWF')
        self.addCurrency(124, 'GHS')
        self.addCurrency(125, 'ARS')
        self.addCurrency(126, 'DOP')
        self.addCurrency(127, 'LBP')
        self.addCurrency(128, 'BZD')
        self.addCurrency(129, 'BTN')
        self.addCurrency(130, 'MYR')
        self.addCurrency(131, 'YER')
        self.addCurrency(132, 'JMD')
        self.addCurrency(133, 'TOP')
        self.addCurrency(134, 'SOS')
        self.addCurrency(135, 'TMT')
        self.addCurrency(136, 'MDL')
        self.addCurrency(137, 'XOF')
        self.addCurrency(138, 'TWD')
        self.addCurrency(139, 'BBD')
        self.addCurrency(140, 'CAD')
        self.addCurrency(141, 'CNY')
        self.addCurrency(142, 'JOD')
        self.addCurrency(143, 'XPF')
        self.addCurrency(144, 'IQD')
        self.addCurrency(145, 'HNL')
        self.addCurrency(146, 'AED')
        self.addCurrency(147, 'ERN')
        self.addCurrency(148, 'KES')
        self.addCurrency(149, 'KMF')
        self.addCurrency(150, 'MKD')
        self.addCurrency(151, 'DZD')
        self.addCurrency(152, 'CUP')
        self.addCurrency(153, 'BWP')
        self.addCurrency(154, 'SBD')
        self.addCurrency(155, 'AZN')
        self.addCurrency(156, 'KGS')
        self.addCurrency(157, 'KHR')
        self.addCurrency(158, 'ZMK')
        self.addCurrency(159, 'HTG')
        self.addCurrency(160, 'CZK')
        self.addCurrency(161, 'BAM')

class AccountGroup:
    def __init__(self, \
        accountGroupID, \
        accountGroupUUID, \
        sample, \
        name, \
        showBalances, \
        includeInTotal, \
        accountGroupOrder):
        self.accountGroupID = accountGroupID
        self.accountGroupUUID = accountGroupUUID
        self.sample = sample
        self.name = name
        self.showBalances = showBalances
        self.includeInTotal = includeInTotal
        self.accountGroupOrder = accountGroupOrder

class AccountGroups:
    def __init__(self, csvLanguage):
        if CSVLanguage.English == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "My Accounts", "Archived Accounts"
        elif CSVLanguage.German == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "Meine Konten", "Archivierte Konten"
        elif CSVLanguage.Spanish == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "Mis cuentas", "Cuentas archivadas"
        elif CSVLanguage.French == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "Mes comptes", "Comptes archivés"
        elif CSVLanguage.Italian == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "I miei conti", "Conti archiviati"
        elif CSVLanguage.Dutch == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "Mijn Rekeningen", "Gearchiveerde Rekeningen"
        elif CSVLanguage.Portuguese == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "Minhas Contas", "Contas Realizadas"
        elif CSVLanguage.Russian == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "Мои счета", "Архив"
        elif CSVLanguage.Ukrainian == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "Мої рахунки", "Архів"
        elif CSVLanguage.ChineseSimplified == csvLanguage:
            myAccountsAGName, archivedAccountsAGName = "我的帐户", "存档的帐户"
        else:
            print("Internal error: Bad language:", csvLanguage)
            assert False
            sys.exit(1)
        self.myAccountsAG = AccountGroup( \
            1, \
            "8aa5009bc77347dba74b5b8b846dd77b", \
            True, \
            myAccountsAGName, \
            True, \
            True, \
            0)
        self.archivedAccountsAG = AccountGroup( \
            2, \
            "a4b1bb52230b49f1b84f45af9661ef13", \
            True, \
            archivedAccountsAGName, \
            False, \
            False, \
            1)
        self.accountGroupList = [self.myAccountsAG, self.archivedAccountsAG]

class Account:
    def __init__(self, \
        accountID, \
        accountUUID, \
        sample, \
        name, \
        currencyIDOrInvalid, \
        note, \
        accountGroupIDOrInvalid, \
        accountOrder):
        self.accountID = accountID
        self.accountUUID = accountUUID
        self.sample = sample
        self.name = name
        self.currencyIDOrInvalid = currencyIDOrInvalid
        self.note = note
        self.accountGroupIDOrInvalid = accountGroupIDOrInvalid
        self.accountOrder = accountOrder

class Accounts:
    def __init__(self, inputEntryList, currencies, accountGroups):
        # Make a set of account names.
        accountNameSet = set()
        for inputEntry in inputEntryList:
            if len(inputEntry.account1NameOrEmpty) > 0:
                accountNameSet.add(inputEntry.account1NameOrEmpty)
            if len(inputEntry.account2NameOrEmpty) > 0:
                accountNameSet.add(inputEntry.account2NameOrEmpty)

        # Make used currency sets.
        accountNameToUsedCurrencyCodeSetDict = {}
        for inputEntry in inputEntryList:
            if len(inputEntry.account1NameOrEmpty) > 0:
                if 0 == len(inputEntry.currency1CodeOrEmpty):
                    print("Error: %s, row %d: Empty currency 1 code" \
                        % (inputEntry.inputFilePath, inputEntry.rowNumber))
                    sys.exit(1)
                if inputEntry.currency1CodeOrEmpty not in currencies.currencyCodeToIDDict:
                    print("Error: %s, row %d: Bad currency 1 code: \"%s\"" \
                        % (inputEntry.inputFilePath, inputEntry.rowNumber, inputEntry.currency1CodeOrEmpty))
                    sys.exit(1)
                if not inputEntry.account1NameOrEmpty in accountNameToUsedCurrencyCodeSetDict:
                    accountNameToUsedCurrencyCodeSetDict[inputEntry.account1NameOrEmpty] = set()
                accountNameToUsedCurrencyCodeSetDict[inputEntry.account1NameOrEmpty].add(inputEntry.currency1CodeOrEmpty)
            if len(inputEntry.account2NameOrEmpty) > 0:
                if 0 == len(inputEntry.currency3CodeOrEmpty):
                    print("Error: %s, row %d: Empty currency 3 code" \
                        % (inputEntry.inputFilePath, inputEntry.rowNumber))
                    sys.exit(1)
                if inputEntry.currency3CodeOrEmpty not in currencies.currencyCodeToIDDict:
                    print("Error: %s, row %d: Bad currency 3 code: \"%s\"" \
                        % (inputEntry.inputFilePath, inputEntry.rowNumber, inputEntry.currency3CodeOrEmpty))
                    sys.exit(1)
                if not inputEntry.account2NameOrEmpty in accountNameToUsedCurrencyCodeSetDict:
                    accountNameToUsedCurrencyCodeSetDict[inputEntry.account2NameOrEmpty] = set()
                accountNameToUsedCurrencyCodeSetDict[inputEntry.account2NameOrEmpty].add(inputEntry.currency3CodeOrEmpty)

        # Create accounts.
        self.accountIDToAccountDict = {}
        self.accountIDList = []
        self.accountNameToIDDict = {}
        accountID = 0
        accountOrder = 0
        for accountName in accountNameSet:
            accountID += 1
            accountUUID = makeUUID()
            currencyIDOrInvalid = 0
            usedCurrencyCodeSet = accountNameToUsedCurrencyCodeSetDict[accountName]
            if 1 == len(usedCurrencyCodeSet):
                (currencyCode, ) = usedCurrencyCodeSet
                currencyIDOrInvalid = currencies.currencyCodeToIDDict[currencyCode]
            accountGroupIDOrInvalid = accountGroups.myAccountsAG.accountGroupID
            account = Account( \
                accountID, \
                accountUUID, \
                False, \
                accountName, \
                currencyIDOrInvalid, \
                "", \
                accountGroupIDOrInvalid, \
                accountOrder)
            accountOrder += 1
            self.accountIDToAccountDict[account.accountID] = account
            self.accountIDList.append(account.accountID)
            self.accountNameToIDDict[account.name] = account.accountID

class Group:
    def __init__(self, \
        groupID, \
        groupUUID, \
        sample, \
        name, \
        groupOrder):
        self.groupID = groupID
        self.groupUUID = groupUUID
        self.sample = sample
        self.name = name
        self.groupOrder = groupOrder

class Groups:
    def __init__(self, inputEntryList):
        # Make a set of group names.
        groupNameSet = set()
        for inputEntry in inputEntryList:
            if len(inputEntry.groupNameOrEmpty) > 0:
                groupNameSet.add(inputEntry.groupNameOrEmpty)

        # Create groups.
        self.groupIDToGroupDict = {}
        self.groupIDList = []
        self.groupNameToIDDict = {}
        groupID = 0
        groupOrder = 0
        for groupName in groupNameSet:
            groupID += 1
            groupUUID = makeUUID()
            group = Group( \
                groupID, \
                groupUUID, \
                False, \
                groupName, \
                groupOrder)
            groupOrder += 1
            self.groupIDToGroupDict[group.groupID] = group
            self.groupIDList.append(group.groupID)
            self.groupNameToIDDict[group.name] = group.groupID

class Party:
    def __init__(self, \
        partyID, \
        partyUUID, \
        sample, \
        name):
        self.partyID = partyID
        self.partyUUID = partyUUID
        self.sample = sample
        self.name = name

class Parties:
    def __init__(self, inputEntryList):
        # Make a set of party names.
        partyNameSet = set()
        for inputEntry in inputEntryList:
            if len(inputEntry.partyNameOrEmpty) > 0:
                partyNameSet.add(inputEntry.partyNameOrEmpty)

        # Create parties.
        self.partyIDToPartyDict = {}
        self.partyIDList = []
        self.partyNameToIDDict = {}
        partyID = 0
        for partyName in partyNameSet:
            partyID += 1
            partyUUID = makeUUID()
            party = Party( \
                partyID, \
                partyUUID, \
                False, \
                partyName)
            self.partyIDToPartyDict[party.partyID] = party
            self.partyIDList.append(party.partyID)
            self.partyNameToIDDict[party.name] = party.partyID

class Tag:
    def __init__(self, \
        tagID, \
        tagUUID, \
        sample, \
        name,
        tagCategoryIDOrInvalid):
        self.tagID = tagID
        self.tagUUID = tagUUID
        self.sample = sample
        self.name = name
        self.tagCategoryIDOrInvalid = tagCategoryIDOrInvalid

class Tags:
    def __init__(self, inputEntryList):
        # Make a set of tag names.
        tagNameSet = set()
        for inputEntry in inputEntryList:
            for tagName in inputEntry.tagNameList:
                tagNameSet.add(tagName)

        # Create tags.
        self.tagIDToTagDict = {}
        self.tagIDList = []
        self.tagNameToIDDict = {}
        tagID = 0
        for tagName in tagNameSet:
            tagID += 1
            tagUUID = makeUUID()
            tag = Tag( \
                tagID, \
                tagUUID, \
                False, \
                tagName, \
                0)
            self.tagIDToTagDict[tag.tagID] = tag
            self.tagIDList.append(tag.tagID)
            self.tagNameToIDDict[tag.name] = tag.tagID

class ReportPreset:
    def __init__(self, \
        reportPresetID, \
        reportPresetUUID, \
        sample, \
        name, \
        allAccountsSelected, \
        selectedAccountCount, \
        unspecifiedAccountSelected, \
        allCurrenciesSelected, \
        selectedCurrencyCount, \
        startDateKind, \
        customStartDateOrInvalid, \
        startTime, \
        endDateKind, \
        customEndDateOrInvalid, \
        endTime, \
        allGroupsSelected, \
        selectedGroupCount, \
        unspecifiedGroupSelected, \
        allPartiesSelected, \
        selectedPartyCount, \
        unspecifiedPartySelected, \
        allTagsSelected, \
        selectedTagCount, \
        unspecifiedTagSelected, \
        reportPresetOrder):
        self.reportPresetID = reportPresetID
        self.reportPresetUUID = reportPresetUUID
        self.sample = sample
        self.name = name
        self.allAccountsSelected = allAccountsSelected
        self.selectedAccountCount = selectedAccountCount
        self.unspecifiedAccountSelected = unspecifiedAccountSelected
        self.allCurrenciesSelected = allCurrenciesSelected
        self.selectedCurrencyCount = selectedCurrencyCount
        self.startDateKind = startDateKind
        self.customStartDateOrInvalid = customStartDateOrInvalid
        self.startTime = startTime
        self.endDateKind = endDateKind
        self.customEndDateOrInvalid = customEndDateOrInvalid
        self.endTime = endTime
        self.allGroupsSelected = allGroupsSelected
        self.selectedGroupCount = selectedGroupCount
        self.unspecifiedGroupSelected = unspecifiedGroupSelected
        self.allPartiesSelected = allPartiesSelected
        self.selectedPartyCount = selectedPartyCount
        self.unspecifiedPartySelected = unspecifiedPartySelected
        self.allTagsSelected = allTagsSelected
        self.selectedTagCount = selectedTagCount
        self.unspecifiedTagSelected = unspecifiedTagSelected
        self.reportPresetOrder = reportPresetOrder

class ReportPresets:
    def __init__(self, csvLanguage):
        if CSVLanguage.English == csvLanguage:
            thisMonthRPName, allEntriesRPName = "This Month", "All Entries"
        elif CSVLanguage.German == csvLanguage:
            thisMonthRPName, allEntriesRPName = "Diesen Monat", "Alle Eingaben"
        elif CSVLanguage.Spanish == csvLanguage:
            thisMonthRPName, allEntriesRPName = "Este mes", "T\u006Fdos los registros"
        elif CSVLanguage.French == csvLanguage:
            thisMonthRPName, allEntriesRPName = "Ce mois-ci", "Toutes les entrées"
        elif CSVLanguage.Italian == csvLanguage:
            thisMonthRPName, allEntriesRPName = "Questo mese", "Tutte le transazioni"
        elif CSVLanguage.Dutch == csvLanguage:
            thisMonthRPName, allEntriesRPName = "Deze maand", "Alle posten"
        elif CSVLanguage.Portuguese == csvLanguage:
            thisMonthRPName, allEntriesRPName = "Este Mês", "T\u006Fdos Registros"
        elif CSVLanguage.Russian == csvLanguage:
            thisMonthRPName, allEntriesRPName = "Этот месяц", "Все записи"
        elif CSVLanguage.Ukrainian == csvLanguage:
            thisMonthRPName, allEntriesRPName = "Цей місяць", "Всі записи"
        elif CSVLanguage.ChineseSimplified == csvLanguage:
            thisMonthRPName, allEntriesRPName = "本月", "所有条目"
        else:
            print("Internal error: Bad language:", csvLanguage)
            assert False
            sys.exit(1)
        self.thisMonthRP = ReportPreset( \
            1, \
            "d6dff2c7efe9478ba8c05abc19f90bf9", \
            True, \
            thisMonthRPName, \
            True, \
            0, \
            True, \
            True, \
            0, \
            # "Beginning of Month"
            4, \
            0, \
            0, \
            # "End of Month"
            5, \
            0, \
            235959, \
            True, \
            0, \
            True, \
            True, \
            0, \
            True, \
            True, \
            0, \
            True, \
            0)
        self.allEntriesRP = ReportPreset( \
            2, \
            "7ae6489137294fc9a20b617e6eec8ed2", \
            True, \
            allEntriesRPName, \
            True, \
            0, \
            True, \
            True, \
            0, \
            # "The Very Beginning"
            13, \
            0, \
            0, \
            # "Distant Future"
            9, \
            0, \
            235959, \
            True, \
            0, \
            True, \
            True, \
            0, \
            True, \
            True, \
            0, \
            True, \
            1)
        self.reportPresetList = [self.thisMonthRP, self.allEntriesRP]

def makeRowListFromCSVFile(inputFilePath):
    # Check if file exists, to have a chance of nicely reporting bad input file path to the user.
    if not os.path.exists(inputFilePath):
        print("Error: Could not open file: %s" % inputFilePath)
        sys.exit(1)

    # Determine CSV file type.
    csvFileType = CSVFileType.UTF8CSV
    csvFileBinary = open(inputFilePath, "rb")
    try:
        firstBytes = csvFileBinary.read(2);
        if (255 == firstBytes[0]) and (254 == firstBytes[1]):
            csvFileType = CSVFileType.UTF16TSV
        elif (239 == firstBytes[0]) and (187 == firstBytes[1]):
            # We've got a UTF-8 file; now we must determine the type of separators. For that we need
            # the first line of the file.
            csvFileText = open(inputFilePath, "r")
            firstLine = csvFileText.readline()
            csvFileText.close()

            # We assume that the first line is the header; hence, the following simplistic separator
            # detection code.
            if '","' in firstLine:
                csvFileType = CSVFileType.UTF8CSV
            elif '";"' in firstLine:
                csvFileType = CSVFileType.UTF8ScSV
            else:
                # We fall back to UTF8CSV for now, and will most likely fail during subsequent reads
                csvFileType = CSVFileType.UTF8CSV
        else:
            # If everything else fails, we fall back to UTF8CSV.
            csvFileType = CSVFileType.UTF8CSV
    finally:
        csvFileBinary.close()

    # Open the file for reading.
    if CSVFileType.UTF16TSV == csvFileType:
        # Unlike the "utf-16-le", "utf-16" skips the BOM.
        csvFile = open(inputFilePath, "r", encoding="utf-16")
        csvReader = csv.reader(csvFile, delimiter='\t', quotechar='\"')
    elif CSVFileType.UTF8CSV == csvFileType:
        csvFile = open(inputFilePath, "r", encoding="utf-8-sig")
        csvReader = csv.reader(csvFile, delimiter=',', quotechar='\"')
    elif CSVFileType.UTF8ScSV == csvFileType:
        csvFile = open(inputFilePath, "r", encoding="utf-8-sig")
        csvReader = csv.reader(csvFile, delimiter=';', quotechar='\"')

    # Read rows.
    rowList = []
    for row in csvReader:
        rowList.append(row)

    csvFile.close()
    return rowList

def makeCSVLanguageFromRowList(inputFilePath, rowList):
    firstRow = rowList[0]
    if ["#", "Date", "Time", "Type"] == firstRow[0:4]:
        return CSVLanguage.English
    elif ["#", "Datum", "Zeit", "Art"] == firstRow[0:4]:
        return CSVLanguage.German
    elif ["#", "Fecha", "Hora", "Tipo"] == firstRow[0:4]:
        return CSVLanguage.Spanish
    elif ["#", "Date", "Heure", "Type"] == firstRow[0:4]:
        return CSVLanguage.French
    elif ["#", "Data", "Ora", "Tipo"] == firstRow[0:4]:
        return CSVLanguage.Italian
    elif ["#", "Datum", "Tijd", "Soort"] == firstRow[0:4]:
        return CSVLanguage.Dutch
    elif ["#", "Data", "Hora", "Tipo"] == firstRow[0:4]:
        return CSVLanguage.Portuguese
    elif ["#", "Дата", "Время", "Тип"] == firstRow[0:4]:
        return CSVLanguage.Russian
    elif ["#", "Дата", "Час", "Тип"] == firstRow[0:4]:
        return CSVLanguage.Ukrainian
    elif ["#", "日期", "时间", "类型"] == firstRow[0:4]:
        return CSVLanguage.ChineseSimplified
    else:
        print("Error: %s: Could not determine language, first row: %s" % (inputFilePath, firstRow))
        sys.exit(1)

def checkCSVStructure(inputFilePath, rowList, csvLanguage):
    firstRow = rowList[0]
    if len(firstRow) < 23:
        print("Error: %s: Unsupported CSV structure: %s" % (inputFilePath, firstRow))
        sys.exit(1)
    actualHeaderEntryColumns = firstRow[0:23]
    if CSVLanguage.English == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "Date", \
        "Time", \
        "Type", \
        "Amount / Withdrawal Amount", \
        "Currency Code", \
        "Formatted Amount", \
        "Amount / Withdrawal Amount (Foreign)", \
        "Currency Code", \
        "Formatted Amount", \
        "Deposit Amount", \
        "Currency Code", \
        "Formatted Amount", \
        "Deposit Amount (Foreign)", \
        "Currency Code", \
        "Formatted Amount", \
        "Tags", \
        "Note", \
        "Receipts", \
        "Party", \
        "Account / Withdrawal Account", \
        "Deposit Account", \
        "Group"]
    elif CSVLanguage.German == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "Datum", \
        "Zeit", \
        "Art", \
        "Betrag / Abhebung", \
        "Währungscode", \
        "Formatierten Betrag", \
        "Betrag / Abhebung (Fremdwährung)", \
        "Währungscode", \
        "Formatierten Betrag", \
        "Guthaben", \
        "Währungscode", \
        "Formatierten Betrag", \
        "Guthaben (Fremdwährung)", \
        "Währungscode", \
        "Formatierten Betrag", \
        "Kategorien", \
        "Notizen", \
        "Quittungen", \
        "Beteiligter", \
        "Konto / Abhebkonto", \
        "Einzahlkonto", \
        "Gruppe"]
    elif CSVLanguage.Spanish == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "Fecha", \
        "Hora", \
        "Tipo", \
        "Monto / Monto de retiro", \
        "Código de moneda", \
        "Monto formateado", \
        "Monto / Monto de retiro (extranjero)", \
        "Código de moneda", \
        "Monto formateado", \
        "Monto de depósito", \
        "Código de moneda", \
        "Monto formateado", \
        "Monto de depósito (extranjero)", \
        "Código de moneda", \
        "Monto formateado", \
        "Etiquetas", \
        "Nota", \
        "Recibos", \
        "Parte", \
        "Cuenta / Cuenta de retiro", \
        "Cuenta de depósito", \
        "Grupo"]
    elif CSVLanguage.French == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "Date", \
        "Heure", \
        "Type", \
        "Somme / Somme de retrait", \
        "Code de la devise", \
        "Somme formatée", \
        "Somme / Somme de retrait (étrangère)", \
        "Code de la devise", \
        "Somme formatée", \
        "Somme du dépôt", \
        "Code de la devise", \
        "Somme formatée", \
        "Somme du dépôt (étrangère)", \
        "Code de la devise", \
        "Somme formatée", \
        "Étiquettes", \
        "Note", \
        "Reçus", \
        "Partie", \
        "Compte / Compte de retrait", \
        "Compte du dépôt", \
        "Groupe"]
    elif CSVLanguage.Italian == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "Data", \
        "Ora", \
        "Tipo", \
        "Importo / Importo di prelievo", \
        "Codice valuta", \
        "Importo formattato", \
        "Importo / Importo di prelievo (estero)", \
        "Codice valuta", \
        "Importo formattato", \
        "Importo di deposito", \
        "Codice valuta", \
        "Importo formattato", \
        "Importo di deposito (estero)", \
        "Codice valuta", \
        "Importo formattato", \
        "Tag", \
        "Nota", \
        "Quietanze", \
        "Referente", \
        "Conto / Conto di prelievo", \
        "Conto di deposito", \
        "Gruppo"]
    elif CSVLanguage.Dutch == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "Datum", \
        "Tijd", \
        "Soort", \
        "Bedrag / Terugtrekking bedrag", \
        "Valuta code", \
        "Geformatteerd bedrag", \
        "Bedrag / Terugtrekking bedrag (vreemde)", \
        "Valuta code", \
        "Geformatteerd bedrag", \
        "Storting bedrag", \
        "Valuta code", \
        "Geformatteerd bedrag", \
        "Storting bedrag (vreemde)", \
        "Valuta code", \
        "Geformatteerd bedrag", \
        "Labels", \
        "Notitie", \
        "Bonnen", \
        "Relatie", \
        "Rekening / Terugtrekking rekening", \
        "Storting rekening", \
        "Groep"]
    elif CSVLanguage.Portuguese == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "Data", \
        "Hora", \
        "Tipo", \
        "Valor / Valor de Retirada", \
        "Código da Moeda", \
        "Valor Formatado", \
        "Valor / Valor de Retirada (Estrangeiro)", \
        "Código da Moeda", \
        "Valor Formatado", \
        "Valor do Depósito", \
        "Código da Moeda", \
        "Valor Formatado", \
        "Valor do Depósito (Estrangeiro)", \
        "Código da Moeda", \
        "Valor Formatado", \
        "Tags", \
        "Nota", \
        "Recibos", \
        "Empresa", \
        "Conta / Conta de Retirada", \
        "Conta de Depósito", \
        "Grupo"]
    elif CSVLanguage.Russian == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "Дата", \
        "Время", \
        "Тип", \
        "Сумма / Сумма снятия", \
        "Код валюты", \
        "Отформатированная сумма", \
        "Сумма / Сумма снятия (иностранная)", \
        "Код валюты", \
        "Отформатированная сумма", \
        "Сумма зачисления", \
        "Код валюты", \
        "Отформатированная сумма", \
        "Сумма зачисления (иностранная)", \
        "Код валюты", \
        "Отформатированная сумма", \
        "Метки", \
        "Примечание", \
        "Квитанции", \
        "Сторона", \
        "Счет / Счет снятия", \
        "Счет зачисления", \
        "Группа"]
    elif CSVLanguage.Ukrainian == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "Дата", \
        "Час", \
        "Тип", \
        "Сума / Сума зняття", \
        "Код валюти", \
        "Відформатована сума", \
        "Сума / Сума зняття (іноземна)", \
        "Код валюти", \
        "Відформатована сума", \
        "Сума зарахування", \
        "Код валюти", \
        "Відформатована сума", \
        "Сума зарахування (іноземна)", \
        "Код валюти", \
        "Відформатована сума", \
        "Мітки", \
        "Нотатка", \
        "Квитанції", \
        "Сторона", \
        "Рахунок / Рахунок зняття", \
        "Рахунок зарахування", \
        "Група"]
    elif CSVLanguage.ChineseSimplified == csvLanguage:
        expectedHeaderEntryColumns = [ \
        "#", \
        "日期", \
        "时间", \
        "类型", \
        "金额 / 取款金额", \
        "货币代码", \
        "格式化金额", \
        "金额/ 取款金额（外币）", \
        "货币代码", \
        "格式化金额", \
        "存款金额", \
        "货币代码", \
        "格式化金额", \
        "存款金额（外币）", \
        "货币代码", \
        "格式化金额", \
        "标签", \
        "备注", \
        "收據", \
        "交易方", \
        "帐户 / 取款帐户", \
        "存款帐户", \
        "群组"]
    else:
        print("Internal error: Bad language:", csvLanguage)
        assert False
        sys.exit(1)
    if expectedHeaderEntryColumns != actualHeaderEntryColumns:
        print(("Error: " + inputFilePath + ": Bad header entry columns, expected:\n"), expectedHeaderEntryColumns, \
            "\nactual:\n", actualHeaderEntryColumns)
        sys.exit(1)

def makeDateStringFromRow(inputFilePath, row, rowNumber, columnIndex):
    initialDateString = row[columnIndex]
    finalDateString = initialDateString.replace("-", "")
    if 8 != len(finalDateString):
        print("Error: %s: Row #%d: Bad date string: %s" % (inputFilePath, rowNumber, initialDateString))
        sys.exit(1)
    return finalDateString

def makeTimeStringFromRow(inputFilePath, row, rowNumber, columnIndex):
    initialTimeString = row[columnIndex]
    hasAMSuffix = initialTimeString.lower().endswith(TIME_AM_SUFFIX.lower())
    hasPMSuffix = initialTimeString.lower().endswith(TIME_PM_SUFFIX.lower())
    if hasAMSuffix:
        workingTimeString = initialTimeString[0:(len(initialTimeString) - len(TIME_AM_SUFFIX))]
    elif hasPMSuffix:
        workingTimeString = initialTimeString[0:(len(initialTimeString) - len(TIME_PM_SUFFIX))]
    else:
        workingTimeString = initialTimeString
    initialHourString, initialMinuteString = workingTimeString.split(":")
    initialHourInt = int(initialHourString)
    minuteInt = int(initialMinuteString)
    finalHourInt = initialHourInt
    if hasPMSuffix:
        finalHourInt += 12
    return "%d%02d00" % (finalHourInt, minuteInt)

def makeEntryTypeFromRow(inputFilePath, csvLanguage, row, rowNumber, columnIndex):
    entryTypeString = row[columnIndex]
    if CSVLanguage.English == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "Expense": EntryType.Expense, \
            "Income": EntryType.Income, \
            "Transfer": EntryType.Transfer, \
            "Balance Adjustment": EntryType.BalanceAdjustment }
    elif CSVLanguage.German == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "Ausgabe": EntryType.Expense, \
            "Einnahme": EntryType.Income, \
            "Übertrag": EntryType.Transfer, \
            "Guthabenanpassung": EntryType.BalanceAdjustment }
    elif CSVLanguage.Spanish == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "Gasto": EntryType.Expense, \
            "Ingreso": EntryType.Income, \
            "Transferencia": EntryType.Transfer, \
            "Ajuste de saldo": EntryType.BalanceAdjustment }
    elif CSVLanguage.French == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "Frais": EntryType.Expense, \
            "Revenu": EntryType.Income, \
            "Transfert": EntryType.Transfer, \
            "Ajustement du solde": EntryType.BalanceAdjustment }
    elif CSVLanguage.Italian == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "Spesa": EntryType.Expense, \
            "Reddito": EntryType.Income, \
            "Trasferimento": EntryType.Transfer, \
            "Regolazione del saldo": EntryType.BalanceAdjustment }
    elif CSVLanguage.Dutch == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "Uitgaven": EntryType.Expense, \
            "Inkomsten": EntryType.Income, \
            "Overboekingen": EntryType.Transfer, \
            "Balans-aanpassing": EntryType.BalanceAdjustment }
    elif CSVLanguage.Portuguese == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "Despesa": EntryType.Expense, \
            "Renda": EntryType.Income, \
            "Transferência": EntryType.Transfer, \
            "Ajuste do Saldo": EntryType.BalanceAdjustment }
    elif CSVLanguage.Russian == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "Расход": EntryType.Expense, \
            "Доход": EntryType.Income, \
            "Перевод": EntryType.Transfer, \
            "Корректировка баланса": EntryType.BalanceAdjustment }
    elif CSVLanguage.Ukrainian == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "Витрата": EntryType.Expense, \
            "Дохід": EntryType.Income, \
            "Переказ": EntryType.Transfer, \
            "Коригування балансу": EntryType.BalanceAdjustment }
    elif CSVLanguage.ChineseSimplified == csvLanguage:
        entryTypeStringToEntryTypeDict = { \
            "费用": EntryType.Expense, \
            "收入": EntryType.Income, \
            "转账": EntryType.Transfer, \
            "余额调整": EntryType.BalanceAdjustment }
    else:
        print("Internal error: Bad language:", csvLanguage)
        assert False
        sys.exit(1)
    if entryTypeString in entryTypeStringToEntryTypeDict:
        return entryTypeStringToEntryTypeDict[entryTypeString]
    else:
        print("Error: %s: Row #%d: Bad entry type string: %s" % (inputFilePath, rowNumber, entryTypeString))
        sys.exit(1)

def makeAmountStringOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex):
    initialAmountString = row[columnIndex]
    realAmountString = initialAmountString.replace(",", ".")
    if len(realAmountString) > 0:
        realAmountFloat = float(realAmountString)
        amountInt = int(realAmountFloat * 100.0)
        return "%d" % (amountInt)
    else:
        return ""

def makeCurrencyCodeOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex):
    currencyCodeOrEmpty = row[columnIndex]
    if len(currencyCodeOrEmpty) > 0:
        if 3 != len(currencyCodeOrEmpty):
            print("Error: %s: Row #%d: Bad currency code or empty: %s" % (inputFilePath, rowNumber, currencyCodeOrEmpty))
            sys.exit(1)
    return currencyCodeOrEmpty

def makeTagNameListFromRow(inputFilePath, row, rowNumber, columnIndex):
    tagNamesString = row[columnIndex]
    if len(tagNamesString) > 0:
        return tagNamesString.split(", ")
    else:
        return []

def makeNoteFromRow(inputFilePath, row, rowNumber, columnIndex):
    return row[columnIndex]

def makePartyNameOrEmptyFromRow(inputFilePath, row, rowNumber, columnIndex):
    return row[columnIndex]

def makeAccountNameOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex):
    return row[columnIndex]

def makeGroupNameOrEmptyFromRow(inputFilePath, row, rowNumber, columnIndex):
    return row[columnIndex]

def makeInputEntryList(inputFilePath, rowList, csvLanguage):
    inputEntryList = []
    rowNumber = 1;
    for row in rowList:
        rowNumber += 1

        columnIndex = 0

        # Skip record CSV ID column
        columnIndex += 1

        dateString = makeDateStringFromRow(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        timeString = makeTimeStringFromRow(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        entryType = makeEntryTypeFromRow(inputFilePath, csvLanguage, row, rowNumber, columnIndex)
        columnIndex += 1

        amount1StringOrEmpty = makeAmountStringOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        currency1CodeOrEmpty = makeCurrencyCodeOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        # Skip formatted amount column
        columnIndex += 1

        amount2StringOrEmpty = makeAmountStringOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        currency2CodeOrEmpty = makeCurrencyCodeOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        # Skip formatted amount column
        columnIndex += 1

        amount3StringOrEmpty = makeAmountStringOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        currency3CodeOrEmpty = makeCurrencyCodeOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        # Skip formatted amount column
        columnIndex += 1

        amount4StringOrEmpty = makeAmountStringOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        currency4CodeOrEmpty = makeCurrencyCodeOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        # Skip formatted amount column
        columnIndex += 1

        tagNameList = makeTagNameListFromRow(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        note = makeNoteFromRow(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        # Skip receipts column
        columnIndex += 1

        partyNameOrEmpty = makePartyNameOrEmptyFromRow(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        account1NameOrEmpty = makeAccountNameOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        account2NameOrEmpty = makeAccountNameOrEmptyFromRowColumn(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        groupNameOrEmpty = makeGroupNameOrEmptyFromRow(inputFilePath, row, rowNumber, columnIndex)
        columnIndex += 1

        inputEntry = InputEntry( \
            inputFilePath = inputFilePath, \
            rowNumber = rowNumber, \
            dateString = dateString, \
            timeString = timeString, \
            entryType = entryType, \
            amount1StringOrEmpty = amount1StringOrEmpty, \
            currency1CodeOrEmpty = currency1CodeOrEmpty, \
            amount2StringOrEmpty = amount2StringOrEmpty, \
            currency2CodeOrEmpty = currency2CodeOrEmpty, \
            amount3StringOrEmpty = amount3StringOrEmpty, \
            currency3CodeOrEmpty = currency3CodeOrEmpty, \
            amount4StringOrEmpty = amount4StringOrEmpty, \
            currency4CodeOrEmpty = currency4CodeOrEmpty, \
            tagNameList = tagNameList, \
            note = note, \
            partyNameOrEmpty = partyNameOrEmpty, \
            account1NameOrEmpty = account1NameOrEmpty, \
            account2NameOrEmpty = account2NameOrEmpty, \
            groupNameOrEmpty = groupNameOrEmpty)
        inputEntryList.append(inputEntry)
    return inputEntryList

def fillMainDatabase(csvLanguageList, inputEntryList, currencies, accountGroups, accounts, groups, parties, tags, reportPresets, database):
    # Fill the "discardedSampleUUIDs" table.
    # The 8aa5009bc77347dba74b5b8b846dd77b and a4b1bb52230b49f1b84f45af9661ef13 UUIDs ("My Accounts"
    # and "Archived Accounts" account groups), and the d6dff2c7efe9478ba8c05abc19f90bf9
    # and 7ae6489137294fc9a20b617e6eec8ed2 UUIDs ("This Month" and "All Entries" report presets) are excluded.
    database.execute( \
        """INSERT INTO discardedSampleUUIDs (uuid) VALUES
        ("03600f684789419da6d21e43a55cb012"),
        ("0ade4e275beb4f4eaf6850f3852a84f8"),
        ("147bdeeccce641a085908f7332dba321"),
        ("152d4af5d1c24a5098283b32994c3a9d"),
        ("172ad8fc82524c059bf52fd5976a0d3e"),
        ("192f57b8b27c45b3b8634e25f88f6920"),
        ("1e2a6bc2e19641f99e00a9ff7e8b7997"),
        ("22083e997b7947818de15ed7e16ad8bb"),
        ("3937f96061df4a579c90af7298b67895"),
        ("3bde0569df6d4c92aac0861767997b7a"),
        ("4a24050bbbb04cefb6e8c921b48f21fd"),
        ("5dcd88af375e412aa12dd1ab3216e6c9"),
        ("619a028e89794a948d7eee6fbdd95898"),
        ("67e4c8906130497a9920e4d121db44f7"),
        ("7124eb3a3e4f40aa8b9660bcb547a11b"),
        ("7c9d927fe126496c94267bdf30d157f0"),
        ("8f466fc0590a4e53984abb0fb4d8a44b"),
        ("932935f3c13645c5a65ee3b502b11cae"),
        ("95f67aa480bb4e5db787cfe3ae4cdda9"),
        ("99a8fcb35702424a9ab58ddf3300d011"),
        ("9c740effff37417eb6d81cc115b43734"),
        ("a5fa773041a84bd093fb3c3da58b3a98"),
        ("ac317ba4d0404f209ae086d0a2059965"),
        ("ad2176e83b0f4dc394cd4359b69aa1c0"),
        ("b1ae11c498144451b7a6e182495d6661"),
        ("b84b1439e32e44fdb13125ba49fd3d39"),
        ("d44b2aaff28146a0ba7af49c4a7d51aa"),
        ("dce15a3b42a7454ebb7012c515cbc046"),
        ("f227896746da437f9cb2312eed8d0830")
        """)
    database.commit()

    # This is a fix for the case when, for example, there are no groups at all, and the app would try to re-create sample content.
    database.execute( \
        """INSERT INTO workspaceLocalSettings (key, value) VALUES
        ("sampleContentVersion", 1)
        """)
    database.commit()

    # Fill the "currencies" table.
    currencyIDCodeList = []
    for currencyID in currencies.currencyIDToCodeDict:
        currencyCode = currencies.currencyIDToCodeDict[currencyID]
        currencyIDCodeList.append("(%d, \"%s\")" % (int(currencyID), currencyCode))
    database.execute("INSERT INTO currencies (currencyID, currencyCode) VALUES " + ", ".join(currencyIDCodeList))
    database.commit()

    # Fill the "selectedCurrencies" table.
    database.execute("INSERT INTO selectedCurrencies (selectedCurrencyID, selectedCurrencyOrder) VALUES (?, ?)", \
        (currencies.currencyCodeToIDDict["USD"], 0))
    database.execute("INSERT INTO selectedCurrencies (selectedCurrencyID, selectedCurrencyOrder) VALUES (?, ?)", \
        (currencies.currencyCodeToIDDict["EUR"], 1))
    if CSVLanguage.Russian in csvLanguageList:
        database.execute("INSERT INTO selectedCurrencies (selectedCurrencyID, selectedCurrencyOrder) VALUES (?, ?)", \
            (currencies.currencyCodeToIDDict["RUB"], 2))
    database.commit()

    # Fill the "accountGroups" table.
    for accountGroup in accountGroups.accountGroupList:
        database.execute( \
            """INSERT INTO accountGroups (
            accountGroupID,
            accountGroupUUID,
            sample,
            name,
            showBalances,
            includeInTotal,
            accountGroupOrder
            ) VALUES (?, ?, ?, ?, ?, ?, ?)""", \
            (accountGroup.accountGroupID, \
            accountGroup.accountGroupUUID, \
            int(accountGroup.sample), \
            accountGroup.name, \
            int(accountGroup.showBalances), \
            int(accountGroup.includeInTotal), \
            accountGroup.accountGroupOrder))
    database.commit()

    # Fill the "accounts" table.
    print("Creating %d accounts..." % len(accounts.accountIDList))
    for accountID in accounts.accountIDList:
        account = accounts.accountIDToAccountDict[accountID]
        database.execute( \
            """INSERT INTO accounts (
            accountID,
            accountUUID,
            sample,
            name,
            currencyIDOrInvalid,
            note,
            accountGroupIDOrInvalid,
            accountOrder
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)""", \
            (account.accountID, \
            account.accountUUID, \
            int(account.sample), \
            account.name, \
            account.currencyIDOrInvalid, \
            account.note, \
            account.accountGroupIDOrInvalid, \
            account.accountOrder))
    database.commit()

    # Fill the "groups" table.
    print("Creating %d groups..." % len(groups.groupIDList))
    for groupID in groups.groupIDList:
        group = groups.groupIDToGroupDict[groupID]
        database.execute( \
            """INSERT INTO groups (
            groupID,
            groupUUID,
            sample,
            name,
            groupOrder
            ) VALUES (?, ?, ?, ?, ?)""", \
            (group.groupID, \
            group.groupUUID, \
            int(group.sample), \
            group.name, \
            group.groupOrder))
    database.commit()

    # Fill the "parties" table.
    print("Creating %d parties..." % len(parties.partyIDList))
    for partyID in parties.partyIDList:
        party = parties.partyIDToPartyDict[partyID]
        database.execute( \
            """INSERT INTO parties (
            partyID,
            partyUUID,
            sample,
            name
            ) VALUES (?, ?, ?, ?)""", \
            (party.partyID, \
            party.partyUUID, \
            int(party.sample), \
            party.name))
    database.commit()

    # Fill the "tags" table.
    print("Creating %d tags..." % len(tags.tagIDList))
    for tagID in tags.tagIDList:
        tag = tags.tagIDToTagDict[tagID]
        database.execute( \
            """INSERT INTO tags (
            tagID,
            tagUUID,
            sample,
            name,
            tagCategoryIDOrInvalid
            ) VALUES (?, ?, ?, ?, ?)""", \
            (tag.tagID, \
            tag.tagUUID, \
            int(tag.sample), \
            tag.name, \
            tag.tagCategoryIDOrInvalid))
    database.commit()

    # Fill the "records", "recordTags", and "recordFiles" tables.
    print("Creating %d entries..." % len(inputEntryList))
    entryID = 0
    workingTimestamp = int(time.time())
    for inputEntry in inputEntryList:
        # Make output entry.
        entryID += 1
        entryUUID = makeUUID()
        sample = False
        entryType = inputEntry.entryType
        account1IDOrInvalid = 0
        account2IDOrInvalid = 0
        if len(inputEntry.account1NameOrEmpty) > 0:
            account1IDOrInvalid = accounts.accountNameToIDDict[inputEntry.account1NameOrEmpty]
        if len(inputEntry.account2NameOrEmpty) > 0:
            account2IDOrInvalid = accounts.accountNameToIDDict[inputEntry.account2NameOrEmpty]
        hasForeignAmount1 = False
        if len(inputEntry.currency2CodeOrEmpty) > 0:
            hasForeignAmount1 = True
        hasForeignAmount2 = False
        if len(inputEntry.currency4CodeOrEmpty) > 0:
            if (EntryType.Expense == inputEntry.entryType) \
                or (EntryType.Income == inputEntry.entryType) \
                or (EntryType.BalanceAdjustment == inputEntry.entryType):
                print("Error: %s: Row #%d: Unexpected currency code 4" \
                    % (inputEntry.inputFilePath, inputEntry.rowNumber))
                sys.exit(1)
            elif EntryType.Transfer == inputEntry.entryType:
                hasForeignAmount2 = True
        if 0 == len(inputEntry.currency1CodeOrEmpty):
            print("Error: %s: Row #%d: Missing currency code 1" \
                % (inputEntry.inputFilePath, inputEntry.rowNumber))
            sys.exit(1)
        currency1IDOrInvalid = currencies.currencyCodeToIDDict[inputEntry.currency1CodeOrEmpty]
        amount1 = int(inputEntry.amount1StringOrEmpty)
        currency2IDOrInvalid = 0
        amount2 = 0
        if hasForeignAmount1:
            currency2IDOrInvalid = currencies.currencyCodeToIDDict[inputEntry.currency2CodeOrEmpty]
            amount2 = int(inputEntry.amount2StringOrEmpty)
        currency3IDOrInvalid = 0
        amount3 = 0
        currency4IDOrInvalid = 0
        amount4 = 0
        if (EntryType.Expense == inputEntry.entryType) \
            or (EntryType.Income == inputEntry.entryType) \
            or (EntryType.BalanceAdjustment == inputEntry.entryType):
            if len(inputEntry.currency3CodeOrEmpty) > 0:
                print("Error: %s: Row #%d: Unexpected currency code 3" \
                    % (inputEntry.inputFilePath, inputEntry.rowNumber))
                sys.exit(1)
            if len(inputEntry.currency4CodeOrEmpty) > 0:
                print("Error: %s: Row #%d: Unexpected currency code 4" \
                    % (inputEntry.inputFilePath, inputEntry.rowNumber))
                sys.exit(1)
        elif EntryType.Transfer == inputEntry.entryType:
            if 0 == len(inputEntry.currency3CodeOrEmpty):
                print("Error: %s: Row #%d: Missing currency code 3" \
                    % (inputEntry.inputFilePath, inputEntry.rowNumber))
                sys.exit(1)
            currency3IDOrInvalid = currencies.currencyCodeToIDDict[inputEntry.currency3CodeOrEmpty]
            amount3 = int(inputEntry.amount3StringOrEmpty)
            if hasForeignAmount2:
                currency4IDOrInvalid = currencies.currencyCodeToIDDict[inputEntry.currency4CodeOrEmpty]
                amount4 = int(inputEntry.amount4StringOrEmpty)
        localDate = int(inputEntry.dateString)
        localTime = int(inputEntry.timeString)
        gmtDate = localDate
        gmtTime = localTime
        tagIDList = []
        for tagName in inputEntry.tagNameList:
            tagID = tags.tagNameToIDDict[tagName]
            tagIDList.append(tagID)
        tagCount = len(tagIDList)
        note = inputEntry.note
        fileCount = 0
        partyIDOrInvalid = 0
        if len(inputEntry.partyNameOrEmpty) > 0:
            partyIDOrInvalid = parties.partyNameToIDDict[inputEntry.partyNameOrEmpty]
        groupIDOrInvalid = 0
        if len(inputEntry.groupNameOrEmpty) > 0:
            groupIDOrInvalid = groups.groupNameToIDDict[inputEntry.groupNameOrEmpty]
        creationTimestamp = workingTimestamp
        modificationTimestamp = creationTimestamp

        # Write the entry into the main table.
        database.execute( \
            """INSERT INTO records (
            recordID,
            recordUUID,
            sample,
            recordKind,
            account1IDOrInvalid,
            account2IDOrInvalid,
            hasForeignAmount1,
            hasForeignAmount2,
            currency1IDOrInvalid,
            amount1,
            currency2IDOrInvalid,
            amount2,
            currency3IDOrInvalid,
            amount3,
            currency4IDOrInvalid,
            amount4,
            localDate,
            localTime,
            gmtDate,
            gmtTime,
            tagCount,
            note,
            fileCount,
            partyIDOrInvalid,
            groupIDOrInvalid,
            creationTimestamp,
            modificationTimestamp
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", \
            (entryID, \
            entryUUID, \
            int(sample), \
            entryType, \
            account1IDOrInvalid, \
            account2IDOrInvalid, \
            hasForeignAmount1, \
            hasForeignAmount2, \
            currency1IDOrInvalid, \
            amount1, \
            currency2IDOrInvalid, \
            amount2, \
            currency3IDOrInvalid, \
            amount3, \
            currency4IDOrInvalid, \
            amount4, \
            localDate, \
            localTime, \
            gmtDate, \
            gmtTime, \
            tagCount, \
            note, \
            fileCount, \
            partyIDOrInvalid, \
            groupIDOrInvalid, \
            creationTimestamp, \
            modificationTimestamp))

        # Write the entry into the tags subtable.
        database.execute( \
            """INSERT INTO recordTags (
            recordID,
            tagRelaxedOrderOrMinusOne,
            tagIDOrInvalid
            ) VALUES (?, ?, ?)""", \
            (entryID, \
            -1, \
            0))
        tagIDIndex = 0
        for tagID in tagIDList:
            database.execute( \
                """INSERT INTO recordTags (
                recordID,
                tagRelaxedOrderOrMinusOne,
                tagIDOrInvalid
                ) VALUES (?, ?, ?)""", \
                (entryID, \
                tagIDIndex, \
                tagID))
            tagIDIndex += 1

        # Write the entry into the files subtable.
        database.execute( \
            """INSERT INTO recordFiles (
            recordID,
            fileRelaxedOrderOrMinusOne,
            fileIDOrInvalid
            ) VALUES (?, ?, ?)""", \
            (entryID, \
            -1, \
            0))

        # Decrease working timestamp, in order not to have all the entries with identical timestamps.
        workingTimestamp -= 1
    database.commit()

    # Fill the "reportPresets" table.
    for reportPreset in reportPresets.reportPresetList:
        database.execute( \
            """INSERT INTO reportPresets (
            reportPresetID,
            reportPresetUUID,
            sample,
            name,
            allAccountsSelected,
            selectedAccountCount,
            unspecifiedAccountSelected,
            allCurrenciesSelected,
            selectedCurrencyCount,
            startDateKind,
            customStartDateOrInvalid,
            startTime,
            endDateKind,
            customEndDateOrInvalid,
            endTime,
            allGroupsSelected,
            selectedGroupCount,
            unspecifiedGroupSelected,
            allPartiesSelected,
            selectedPartyCount,
            unspecifiedPartySelected,
            allTagsSelected,
            selectedTagCount,
            unspecifiedTagSelected,
            reportPresetOrder
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""", \
            (reportPreset.reportPresetID, \
            reportPreset.reportPresetUUID, \
            int(reportPreset.sample), \
            reportPreset.name, \
            int(reportPreset.allAccountsSelected),
            reportPreset.selectedAccountCount, \
            int(reportPreset.unspecifiedAccountSelected), \
            int(reportPreset.allCurrenciesSelected), \
            reportPreset.selectedCurrencyCount, \
            reportPreset.startDateKind, \
            reportPreset.customStartDateOrInvalid, \
            reportPreset.startTime, \
            reportPreset.endDateKind, \
            reportPreset.customEndDateOrInvalid, \
            reportPreset.endTime, \
            int(reportPreset.allGroupsSelected), \
            reportPreset.selectedGroupCount, \
            int(reportPreset.unspecifiedGroupSelected), \
            int(reportPreset.allPartiesSelected), \
            reportPreset.selectedPartyCount, \
            int(reportPreset.unspecifiedPartySelected), \
            int(reportPreset.allTagsSelected), \
            reportPreset.selectedTagCount, \
            int(reportPreset.unspecifiedTagSelected), \
            reportPreset.reportPresetOrder))
    database.commit()

def addDirectoryAsTopLevelToZipFile(directoryPath, zipFile):
    parentDirectoryPlusSeparatorPath = os.path.dirname(directoryPath) + os.sep
    for presentDirectoryPath, subdirectoryNameList, fileNameList in os.walk(directoryPath):
        for subdirectoryName in subdirectoryNameList:
            subdirectoryPath = presentDirectoryPath + os.sep + subdirectoryName
            subdirectoryZipPath = subdirectoryPath[len(parentDirectoryPlusSeparatorPath):]
            zipFile.write(subdirectoryPath, subdirectoryZipPath)
        for fileName in fileNameList:
            filePath = presentDirectoryPath + os.sep + fileName
            fileZipPath = filePath[len(parentDirectoryPlusSeparatorPath):]
            zipFile.write(filePath, fileZipPath)

def main(inputFilePathList, converterDirectoryPath):
    # Read input files.
    assert len(inputFilePathList) > 0
    csvLanguageList = []
    combinedInputEntryList = []
    for inputFilePath in inputFilePathList:
        print("Reading %s..." % inputFilePath)
        rowList = makeRowListFromCSVFile(inputFilePath)
        csvLanguage = makeCSVLanguageFromRowList(inputFilePath, rowList)
        csvLanguageList.append(csvLanguage)
        print("Language: %s" % csvLanguage)
        checkCSVStructure(inputFilePath, rowList, csvLanguage)
        inputEntryList = makeInputEntryList(inputFilePath, rowList[1:], csvLanguage)
        print("Read %d entries" % len(inputEntryList))
        combinedInputEntryList.extend(inputEntryList)
    print("Total entries read: %d" % len(combinedInputEntryList))

    # Prepare temporary output directory.
    temporaryOutputDirectoryPath = converterDirectoryPath + os.sep + TEMPORARY_OUTPUT_DIRECTORY_NAME
    print("Recreating temporary output directory: %s..." % temporaryOutputDirectoryPath)
    if os.path.isdir(temporaryOutputDirectoryPath):
        shutil.rmtree(temporaryOutputDirectoryPath)
    os.makedirs(temporaryOutputDirectoryPath);
    backupDirectoryPath = temporaryOutputDirectoryPath + os.sep + BACKUP_DIRECTORY_NAME
    os.makedirs(backupDirectoryPath);
    emptyMainDatabasePath = converterDirectoryPath + os.sep + EMPTY_MAIN_DATABASE_FILE_NAME
    mainDatabasePath = backupDirectoryPath + os.sep + MAIN_DATABASE_FILE_NAME
    shutil.copyfile(emptyMainDatabasePath, mainDatabasePath)
    filesDirectoryPath = backupDirectoryPath + os.sep + FILES_DIRECTORY_NAME
    os.makedirs(filesDirectoryPath);

    # Fill database.
    currencies = Currencies()
    accountGroups = AccountGroups(csvLanguageList[0])
    accounts = Accounts(combinedInputEntryList, currencies, accountGroups)
    groups = Groups(combinedInputEntryList)
    parties = Parties(combinedInputEntryList)
    tags = Tags(combinedInputEntryList)
    reportPresets = ReportPresets(csvLanguageList[0])
    database = sqlite3.connect(mainDatabasePath)
    fillMainDatabase(csvLanguageList, combinedInputEntryList, currencies, accountGroups, accounts, groups, parties, tags, reportPresets, database)
    database.close()

    # Create output backup file, and clean up.
    outputBackupFilePath = converterDirectoryPath + os.sep + OUTPUT_BACKUP_FILE_NAME
    print("Creating output backup file: %s..." % outputBackupFilePath)
    if os.path.exists(outputBackupFilePath):
        os.remove(outputBackupFilePath)
    zipFile = zipfile.ZipFile(outputBackupFilePath, "w", zipfile.ZIP_DEFLATED)
    addDirectoryAsTopLevelToZipFile(backupDirectoryPath, zipFile)
    zipFile.close()
    shutil.rmtree(temporaryOutputDirectoryPath)

if "__main__" == __name__:
    if len(sys.argv) < 2:
        print("Usage: %s InputFile1.csv [InputFile2.csv ...]" % sys.argv[0])
        sys.exit(1)
    inputFilePathList = sys.argv[1:]
    converterDirectoryPath = os.path.dirname(os.path.realpath(__file__))
    main(inputFilePathList, converterDirectoryPath)
